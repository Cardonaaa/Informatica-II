def verificacion(usuario, contraseña):
    import os
    archivos = "admin/login.txt"

    if os.path.exists(archivos):
        with open(archivos, "r") as archivo:
            lineas = archivo.readlines()
            for linea in lineas:
                clave, valor = linea.strip().split(":")
                if clave.strip() == usuario and valor.strip() == contraseña:
                    return True
    return False


def leer():
    import os
    archivos = "admin/login.txt"
    usuarios = {}

    if os.path.exists(archivos):
        with open(archivos, "r") as archivo:
            lineas = archivo.readlines()
            for linea in lineas:
                clave, valor = linea.strip().split(":")
                usuarios[clave.strip()] = valor.strip()

    return usuarios

def escribir(usuarios):
    archivos = "admin/login.txt"

    with open(archivos, "w") as archivo:
        for clave, valor in usuarios.items():
            archivo.write(f"{clave}: {valor}\n")

def insertar():
    usuarios = leer()

    while True:
        usuario = input("Nuevo usuario: ")
        contraseña = input("Nueva Contraseña: ")

        if usuario in usuarios:
            print("El usuario ya existe en la base de datos. Intenta nuevamente.")
        else:
            usuarios[usuario] = contraseña
            escribir(usuarios)
            print("Usuario ingresado a la base de datos de forma exitosa.")
            break

def mostrar():
    usuarios = leer()

    if usuarios:
        print("Usuarios:")
        for usuario, contraseña in usuarios.items():
            print(f"Usuario: {usuario}, Contraseña: {contraseña}")
    else:
        print("No hay usuarios registrados con esos datos.")

def modificar():
    usuarios = leer()

    usuario = input("Usuario a modificar: ")

    if usuario in usuarios:
        nueva_contraseña = input("Nueva contraseña: ")
        usuarios[usuario] = nueva_contraseña
        escribir(usuarios)
        print("Contraseña guardada exitosamente.")
    else:
        print("Usuario no encontrado en la base de datos.")

def eliminar():
    usuarios = leer()

    usuario = input("Usuario a eliminar: ")

    if usuario in usuarios:
        del usuarios[usuario]
        escribir(usuarios)
        print("Usuario eliminado exitosamente de la base de datos.")
    else:
        print("Usuario no encontrado en la base de datos")